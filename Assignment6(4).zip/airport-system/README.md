# Airport Management System

A comprehensive web-based airport management platform built with Vue 3, featuring multi-role access control, real-time flight tracking, and complete baggage management.

## Features

### Multi-Role System
- **Admin**: Manage flights, passengers, and staff
- **Airline Staff**: Check-in passengers and handle baggage
- **Ground Crew**: Security clearance + gate operations (select mode)
- **Gate Staff**: Passenger boarding and flight readiness
- **Passenger**: Query baggage and flight information

### Validation Framework
- Username format validation (lastname + 2 digits)
- Password strength validation (6+ chars, uppercase, lowercase, digit)
- Email format validation (XXX@XXX.XX)
- Phone number validation (10 digits, first digit ≠ 0)
- Flight number validation (2 letters + 4 digits)
- Ticket number validation (10 digits)
- Bag ID validation (6 digits)

### Complete Workflow
1. Admin creates flights and passengers
2. Airline staff checks in passengers and creates baggage records
3. Ground crew performs security clearance
4. Ground crew loads baggage to aircraft
5. Gate staff boards passengers and notifies admin
6. Passengers can query their baggage status

## Tech Stack

- **Vue 3** - Progressive JavaScript framework with Composition API
- **Vue Router** - Official routing library
- **Pinia** - State management
- **Vite** - Next generation build tool

## Quick Start

### Installation

```bash
npm install
```

### Development

```bash
npm run dev
```

Visit http://localhost:5173

### Production Build

```bash
npm run build
```

### Preview Production Build

```bash
npm run preview
```

## Test Accounts

| Role | Username | Password |
|------|----------|----------|
| Admin | admin | Test123 |
| Airline Staff | smith12 | Test123 |
| Ground Crew | garcia23 | Test123 |
| Gate Staff | wilson67 | Test123 |

## Project Structure

```
src/
├── components/          # Reusable UI components
│   ├── AppButton.vue
│   ├── AppCard.vue
│   ├── AppLayout.vue
│   └── FormInput.vue
├── stores/             # Pinia state management
│   ├── auth.js        # Authentication state
│   └── data.js        # Application data
├── utils/             # Utility functions
│   └── validation.js  # Form validation logic
├── views/             # Page components
│   ├── LoginView.vue
│   ├── AdminView.vue
│   ├── AdminPassengersView.vue
│   ├── AdminStaffView.vue
│   ├── AirlineStaffView.vue
│   ├── GroundCrewView.vue
│   ├── GateStaffView.vue
│   └── PassengerView.vue
├── router/            # Route configuration
│   └── index.js
├── App.vue           # Root component
└── main.js          # Application entry point
```

## Validation Rules

### Username
- Admin: No format requirements
- Others: lastname + 2 digits (e.g., smith12)

### Password
- Minimum 6 characters
- At least one uppercase letter
- At least one lowercase letter
- At least one digit

### Email
- Format: XXX@XXX.XX
- Example: user@example.com

### Phone
- Exactly 10 digits
- First digit cannot be 0
- Example: 2145550123

### Flight Number
- 2 uppercase letters + 4 digits
- Example: AA1234

### Ticket Number
- Exactly 10 digits
- Example: 1234567890

### Bag ID
- Exactly 6 digits
- Auto-generated during check-in
- Example: 550102

## Development

### Code Style
- Vue 3 Composition API
- ES6+ JavaScript
- Scoped CSS in components
- Reactive data with ref() and reactive()

### State Management
- Pinia stores for global state
- Separate stores for auth and data
- Persistent state across navigation

### Routing
- Vue Router with named routes
- Route guards for authentication
- Role-based access control

## License

This project is developed for CS 5336/7336 - Web Application Development, Spring 2026.

## Assignment Information

**Course**: CS 5336/7336 - Web Application Development
**Assignment**: Assignment 2 - Frontend Validation
**Semester**: Spring 2026
